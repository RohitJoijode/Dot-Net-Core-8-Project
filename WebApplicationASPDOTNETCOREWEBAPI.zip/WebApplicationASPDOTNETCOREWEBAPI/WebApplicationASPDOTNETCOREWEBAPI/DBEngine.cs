﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplicationASPDOTNETCOREWEBAPI.DAL;

namespace WebApplicationASPDOTNETCOREWEBAPI
{
    public class DBEngine : DbContext
    {
        public DBEngine(DbContextOptions<DBEngine> dbContextOptions)
      : base(dbContextOptions)
        {
        }

        public DbSet<DimAccount> DimAccount { get; set; }

    }
}

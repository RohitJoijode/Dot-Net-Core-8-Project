using WebApplicationASPDOTNETCOREWEBAPI;
using Microsoft.EntityFrameworkCore;
using WebApplicationASPDOTNETCOREWEBAPI.BAL.IRepository;
using WebApplicationASPDOTNETCOREWEBAPI.BAL.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http.HttpResults;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<DBEngine>(options =>
                 options.UseSqlServer(builder.Configuration.GetConnectionString("BloggingDatabase"))
            );
builder.Services.AddScoped<WebApplicationASPDOTNETCOREWEBAPI.BAL.IRepository.IAdventureWorks,WebApplicationASPDOTNETCOREWEBAPI.BAL.Repository.AdventureWorks>();

var app = builder.Build();

// configure exception middleware
app.UseStatusCodePages(async statusCodeContext
    => await Results.Problem(statusCode: statusCodeContext.HttpContext.Response.StatusCode)
        .ExecuteAsync(statusCodeContext.HttpContext));

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();


app.UseAuthorization();

app.MapControllers();

app.Run();

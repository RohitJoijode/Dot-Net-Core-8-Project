using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.Json;
using System.Collections.Generic;
using WebApplicationASPDOTNETCOREWEBAPI.BAL.IRepository;
using WebApplicationASPDOTNETCOREWEBAPI.BRIDGE;
using WebApplicationASPDOTNETCOREWEBAPI.DAL;

namespace WebApplicationASPDOTNETCOREWEBAPI.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]
    public class WeatherForecastController : ControllerBase
    {
        private readonly IAdventureWorks _IAdventureWorks;
        private DBEngine _DBEngine;
        
        public WeatherForecastController(DBEngine DBEngine,IAdventureWorks IAdventureWorks)
        {
            _DBEngine = DBEngine;
            _IAdventureWorks = IAdventureWorks;
        }

        private readonly List<DimAccountModal> _products = new List<DimAccountModal>
        {
            new DimAccountModal { AccountKey = 1, AccountDescription = "Product A"},
            new DimAccountModal { AccountKey = 2, AccountDescription = "Product B"},
            new DimAccountModal { AccountKey = 3, AccountDescription = "Product C"},
        };
        
        [Route("GetTodoItem")]
        [HttpGet]
        public IActionResult GetTodoItem(int id)
        {
            
            var List = _DBEngine.DimAccount.Where(x => x.AccountKey == id).ToList();
            try
            {
                
            }
            catch (Exception ex)
            {
                
            }
            return  Ok(List);
        }

        [Route("GetTodoItem1")]
        [HttpGet]
        public async Task<IActionResult> GetTodoItem1(int id)
        {

            var List = await _IAdventureWorks.GetDimAccount();
            try
            {

            }
            catch (Exception ex)
            {

            }
            return Ok(List);
        }

        [HttpPost,Route("GetDimAccount")]
        public IActionResult GetDimAccount()
        {
            List<DimAccountModal> DimAccountList = new List<DimAccountModal>();
            return Ok("Data Successfully !!!!");
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Web;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Data;
using System.Configuration;
using System.Collections;
using Microsoft.EntityFrameworkCore;
using WebApplicationASPDOTNETCOREWEBAPI.BRIDGE;
using WebApplicationASPDOTNETCOREWEBAPI.BAL.IRepository;
using WebApplicationASPDOTNETCOREWEBAPI.DAL;

namespace WebApplicationASPDOTNETCOREWEBAPI.BAL.Repository
{
    public class AdventureWorks : WebApplicationASPDOTNETCOREWEBAPI.BAL.IRepository.IAdventureWorks
    {

        private readonly DBEngine _DbEngine;
        public AdventureWorks(DBEngine DbEngine)
        {
            _DbEngine = DbEngine;
        }
        public Task<List<DimAccount>> GetDimAccount()
        {

              return _DbEngine.DimAccount.ToListAsync();
        }
    }
}

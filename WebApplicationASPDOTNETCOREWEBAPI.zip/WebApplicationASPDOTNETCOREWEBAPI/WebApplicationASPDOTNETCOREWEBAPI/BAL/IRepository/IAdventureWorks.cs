﻿using WebApplicationASPDOTNETCOREWEBAPI.BRIDGE;
using WebApplicationASPDOTNETCOREWEBAPI.DAL;

namespace WebApplicationASPDOTNETCOREWEBAPI.BAL.IRepository
{
    public interface IAdventureWorks 
    {
        Task<List<DimAccount>> GetDimAccount();
    }
}
